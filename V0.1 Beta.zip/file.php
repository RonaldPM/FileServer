<?php

unlink('test.txt');
?>